<!-- Page Wrapper -->
@extends('hr.layout.layout')
@section('title', $title)

@section('main-section')
    <!-- Page Wrapper -->
    <div class="page-wrapper">
        <div class="content">
            <!-- Breadcrumb -->
            <div class="d-md-flex d-block align-items-center justify-content-between page-breadcrumb mb-3">
                <div class="my-auto mb-2">
                    <h2 class="mb-1">Company</h2>
                    <nav>
                        <ol class="breadcrumb mb-0">

                            <li class="breadcrumb-item active" aria-current="page">Company Profie</li>
                        </ol>
                    </nav>
                </div>
                
            </div>
            <!-- /Breadcrumb -->


            <div class="card">
                
             
                <div class="card-body">
                  <div class="row">
						<div class="col-md-12">
							<div class="d-flex align-items-center flex-wrap row-gap-3 bg-light w-100 rounded p-3 mb-4">                                                
								<div class="d-flex align-items-center justify-content-center avatar avatar-xxl rounded-circle border border-dashed me-2 flex-shrink-0 text-dark frames">
									<img src="assets/img/profiles/avatar-30.jpg" alt="img" class="rounded-circle">
								</div>                                              
								<div class="profile-upload">
									<div class="mb-2">
										<h6 class="mb-1">Upload Company Logo</h6>
										<p class="fs-12">Image should be below 4 mb</p>
									</div>
									<div class="profile-uploader d-flex align-items-center">
										<div class="drag-upload-btn btn btn-sm btn-primary me-2">
											Upload
											<input type="file" class="form-control image-sign" multiple="">
										</div>
										<a href="javascript:void(0);" class="btn btn-light btn-sm">Cancel</a>
									</div>
									
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="mb-3">
								<label class="form-label">Company Name <span class="text-danger"> *</span></label>
								<input type="text" class="form-control">
							</div>									
						</div>
						<div class="col-md-6">
							<div class="mb-3">
								<label class="form-label">Email</label>
								<input type="email" class="form-control">
							</div>									
						</div>
						<div class="col-md-12">
							<div class="mb-3">
								<label class="form-label">Mobile No.</label>
								<input type="text" class="form-control">
							</div>									
						</div>
						<div class="col-md-6">
							<div class="mb-3">
								<label class="form-label">Phone Number </label>
								<input type="text" class="form-control">
							</div>									
						</div>
						<div class="col-md-6">
							<div class="mb-3">
								<label class="form-label">Website</label>
								<input type="text" class="form-control">
							</div>									
						</div>
						<div class="col-md-6">
							<div class="mb-3 ">
								<label class="form-label">PAN No.</label>
								<div class="pass-group">
									<input type="text" class="pass-input form-control">
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="mb-3 ">
								<label class="form-label">GST No.</label>
								<div class="pass-group">
									<input type="text" class="pass-inputs form-control">
								</div>
							</div>
						</div>
						<div class="col-md-12">
							<div class="mb-3">
								<label class="form-label">Address</label>
								<input type="text" class="form-control">
							</div>									
						</div>
						<div class="col-md-6">
							<div class="mb-3 ">
								<label class="form-label">Industry Type <span class="text-danger"> *</span></label>
								<select class="select">
									<option>Select</option>
									<option>Advanced</option>
									<option>Basic</option>
									<option>Enterprise</option>
								</select>
							</div>
						</div>
						<div class="col-md-6">
							<div class="mb-3 ">
								<label class="form-label">Facebook URL <span class="text-danger"> *</span></label>
								<input type="text" class="form-control">
							</div>
						</div>
						<div class="col-md-4">
							<div class="mb-3 ">
								<label class="form-label">Instagram URL<span class="text-danger"> *</span></label>
								<input type="text" class="form-control">
							</div>
						</div>
						<div class="col-md-4">
							<div class="mb-3 ">
								<label class="form-label">Twitter URL<span class="text-danger"> *</span></label>
								<input type="text" class="form-control">
							</div>
						</div>
						<div class="col-md-4">
							<div class="mb-3 ">
								<label class="form-label">Status</label>
								<select class="select">
									<option>Select</option>
									<option>Active</option>
									<option>Inactive</option>
								</select>
							</div>
						</div>
					</div>
                </div>
            </div>

        </div>

        <x-footer />

    </div>
    <!-- /Page Wrapper -->


@endsection


