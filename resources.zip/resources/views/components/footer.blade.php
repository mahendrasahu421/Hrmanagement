<div>
    <!-- Footer Component -->
    <div class="footer d-sm-flex align-items-center justify-content-between border-top bg-white p-3 mt-4">
        <p class="mb-0">2024 - {{ date('Y') }} &copy; Chitragupta – The HR Guardian.</p>
        <p>Designed &amp; Developed By <a href="javascript:void(0);" class="text-primary">Neural Info Solution</a></p>
    </div>
    <!-- /Footer Component -->

</div>
